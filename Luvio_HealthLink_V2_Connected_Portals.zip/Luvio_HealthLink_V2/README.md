# Luvio HealthLink V2 — Connected Portals Prototype

This package contains a connected front-end prototype for the Luvio HealthLink ecosystem.

Portals:
- index.html — main dashboard
- patient.html — patient portal
- reception.html — reception/polyclinic
- doctor.html — doctor portal
- pharmacy.html — pharmacy portal
- diagnostics.html — diagnostics portal
- hospital.html — partner hospital portal
- online-consultation.html — online consultation
- admin.html — admin portal

The demo uses one browser localStorage data layer so a doctor/pharmacy/lab can add demo events and the patient portal can reflect them. It is NOT suitable for real medical data.

Production must replace localStorage with a secure backend/database, real authentication/OTP, RBAC, consent/authorization, audit logging, encryption, secure document storage and appropriate interoperability APIs.
